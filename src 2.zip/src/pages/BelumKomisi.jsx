import React, { useState, useMemo } from "react";
import { useOutletContext } from "react-router-dom";
import { COL } from "@/lib/sheets";
import { useTabData } from "@/lib/usePortalData";
import PageHeader from "@/components/portal/PageHeader";
import BelumKomisiTable from "@/components/portal/BelumKomisiTable";
import TabLoader from "@/components/portal/TabLoader";

// function isPaid(inv) {
//     const s = inv[COL.I_STATUS] || "";
//     return /paid|bayar|lunas/i.test(s) && !/not paid|belum/i.test(s);
// }

// function isIssue(inv) {
//     const s = inv[COL.I_STATUS] || "";
//     return /issue/i.test(s);
// }

export default function BelumKomisi({ office = false }) {
    const { session } = useOutletContext();
    const [tab, setTab] = useState("all");

    const { values, loading, error, timedOut, reload } = useTabData("c1belumtrf", session);
    const belumkomisis = values.c1belumtrf || [];

    const { all, paid, unpaid, issue } = useMemo(() => {
        const p = [], u = [], iss = [];
        // belumkomisis.forEach((i) => {
        //     if (isPaid(i)) p.push(i);
        //     else if (isIssue(i)) iss.push(i);
        //     else u.push(i);
        // });
        return { all: belumkomisis, paid: p, unpaid: u, issue: iss };
    }, [belumkomisis]);

    const list = tab === "paid" ? paid : tab === "unpaid" ? unpaid : tab === "issue" ? issue : all;

    return (
        <div>
            <PageHeader
                title={office ? "Komisi Pending" : "Invoice"}
                subtitle={office ? "Daftar komisi yang belum di transfer" : "-"} action={undefined} />

            {/* <div className="flex gap-1.5 mb-3 flex-wrap">
                {[
                    ["all", `Semua (${all.length})`],
                    ["paid", `Paid (${paid.length})`],
                    ["unpaid", `Unpaid (${unpaid.length})`],
                    ["issue", `Issue (${issue.length})`],
                ].map(([k, l]) => (
                    <button
                        key={k}
                        onClick={() => setTab(k)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${tab === k ? "bg-brand-600 text-white" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500"
                            }`}
                    >
                        {l}
                    </button>
                ))}
            </div> */}
            <TabLoader loading={loading} error={error} timedOut={timedOut} reload={reload}>
                <BelumKomisiTable belumkomisis={list} showCommission={office} />
            </TabLoader>
        </div>
    );
}

