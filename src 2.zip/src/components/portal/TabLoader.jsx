import React from "react";
import Loader, { ErrorState } from "./Loader";

// Wrap a page's content with this instead of each page re-implementing the
// loading/error branches. Only renders `children` once the tab(s) that page
// asked for (via useTabData) have actually loaded.
export default function TabLoader({ loading, error, timedOut, reload, children }) {
  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (loading) return <Loader timedOut={timedOut} onRetry={reload} />;
  return children;
}
